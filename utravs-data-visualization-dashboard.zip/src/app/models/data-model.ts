import {MonthModel} from "./month-model/month-model";

export interface DataModel {
  months: MonthModel[]
}
