import {
  __commonJS
} from "./chunk-WKYGNSYM.js";

// ../../../../node_modules/highcharts/modules/drilldown.js
var require_drilldown = __commonJS({
  "../../../../node_modules/highcharts/modules/drilldown.js"(exports, module) {
    !/**
    * Highcharts JS v11.4.1 (2024-04-04)
    *
    * Highcharts Drilldown module
    *
    * Author: Torstein Honsi
    * License: www.highcharts.com/license
    *
    */
    function(t) {
      "object" == typeof module && module.exports ? (t.default = t, module.exports = t) : "function" == typeof define && define.amd ? define("highcharts/modules/drilldown", ["highcharts"], function(e) {
        return t(e), t.Highcharts = e, t;
      }) : t("undefined" != typeof Highcharts ? Highcharts : void 0);
    }(function(t) {
      "use strict";
      var e = t ? t._modules : {};
      function i(t2, e2, i2, o) {
        t2.hasOwnProperty(e2) || (t2[e2] = o.apply(null, i2), "function" == typeof CustomEvent && window.dispatchEvent(new CustomEvent("HighchartsModuleLoaded", { detail: { path: e2, module: t2[e2] } })));
      }
      i(e, "Extensions/Breadcrumbs/BreadcrumbsDefaults.js", [], function() {
        return { lang: { mainBreadcrumb: "Main" }, options: { buttonTheme: { fill: "none", height: 18, padding: 2, "stroke-width": 0, zIndex: 7, states: { select: { fill: "none" } }, style: { color: "#334eff" } }, buttonSpacing: 5, floating: false, format: void 0, relativeTo: "plotBox", rtl: false, position: { align: "left", verticalAlign: "top", x: 0, y: void 0 }, separator: { text: "/", style: { color: "#666666", fontSize: "0.8em" } }, showFullPath: true, style: {}, useHTML: false, zIndex: 7 } };
      }), i(e, "Extensions/Breadcrumbs/Breadcrumbs.js", [e["Extensions/Breadcrumbs/BreadcrumbsDefaults.js"], e["Core/Templating.js"], e["Core/Globals.js"], e["Core/Utilities.js"]], function(t2, e2, i2, o) {
        let { format: l } = e2, { composed: s } = i2, { addEvent: r, defined: n, extend: a, fireEvent: d, isString: p, merge: h, objectEach: u, pick: c, pushUnique: m } = o;
        function w() {
          if (this.breadcrumbs) {
            let t3 = this.resetZoomButton && this.resetZoomButton.getBBox(), e3 = this.breadcrumbs.options;
            t3 && "right" === e3.position.align && "plotBox" === e3.relativeTo && this.breadcrumbs.alignBreadcrumbsGroup(-t3.width - e3.buttonSpacing);
          }
        }
        function f() {
          this.breadcrumbs && (this.breadcrumbs.destroy(), this.breadcrumbs = void 0);
        }
        function g() {
          let t3 = this.breadcrumbs;
          if (t3 && !t3.options.floating && t3.level) {
            let e3 = t3.options, i3 = e3.buttonTheme, o2 = (i3.height || 0) + 2 * (i3.padding || 0) + e3.buttonSpacing, l2 = e3.position.verticalAlign;
            "bottom" === l2 ? (this.marginBottom = (this.marginBottom || 0) + o2, t3.yOffset = o2) : "middle" !== l2 ? (this.plotTop += o2, t3.yOffset = -o2) : t3.yOffset = void 0;
          }
        }
        function b() {
          this.breadcrumbs && this.breadcrumbs.redraw();
        }
        function v(t3) {
          true === t3.resetSelection && this.breadcrumbs && this.breadcrumbs.alignBreadcrumbsGroup();
        }
        class y {
          static compose(e3, i3) {
            m(s, "Breadcrumbs") && (r(e3, "destroy", f), r(e3, "afterShowResetZoom", w), r(e3, "getMargins", g), r(e3, "redraw", b), r(e3, "selection", v), a(i3.lang, t2.lang));
          }
          constructor(t3, e3) {
            this.elementList = {}, this.isDirty = true, this.level = 0, this.list = [];
            let i3 = h(t3.options.drilldown && t3.options.drilldown.drillUpButton, y.defaultOptions, t3.options.navigation && t3.options.navigation.breadcrumbs, e3);
            this.chart = t3, this.options = i3 || {};
          }
          updateProperties(t3) {
            this.setList(t3), this.setLevel(), this.isDirty = true;
          }
          setList(t3) {
            this.list = t3;
          }
          setLevel() {
            this.level = this.list.length && this.list.length - 1;
          }
          getLevel() {
            return this.level;
          }
          getButtonText(t3) {
            let e3 = this.chart, i3 = this.options, o2 = e3.options.lang, s2 = c(i3.format, i3.showFullPath ? "{level.name}" : "← {level.name}"), r2 = o2 && c(o2.drillUpText, o2.mainBreadcrumb), a2 = i3.formatter && i3.formatter(t3) || l(s2, { level: t3.levelOptions }, e3) || "";
            return (p(a2) && !a2.length || "← " === a2) && n(r2) && (a2 = i3.showFullPath ? r2 : "← " + r2), a2;
          }
          redraw() {
            this.isDirty && this.render(), this.group && this.group.align(), this.isDirty = false;
          }
          render() {
            let t3 = this.chart, e3 = this.options;
            !this.group && e3 && (this.group = t3.renderer.g("breadcrumbs-group").addClass("highcharts-no-tooltip highcharts-breadcrumbs").attr({ zIndex: e3.zIndex }).add()), e3.showFullPath ? this.renderFullPathButtons() : this.renderSingleButton(), this.alignBreadcrumbsGroup();
          }
          renderFullPathButtons() {
            this.destroySingleButton(), this.resetElementListState(), this.updateListElements(), this.destroyListElements();
          }
          renderSingleButton() {
            let t3 = this.chart, e3 = this.list, i3 = this.options.buttonSpacing;
            this.destroyListElements();
            let o2 = this.group ? this.group.getBBox().width : i3, l2 = e3[e3.length - 2];
            !t3.drillUpButton && this.level > 0 ? t3.drillUpButton = this.renderButton(l2, o2, i3) : t3.drillUpButton && (this.level > 0 ? this.updateSingleButton() : this.destroySingleButton());
          }
          alignBreadcrumbsGroup(t3) {
            if (this.group) {
              let e3 = this.options, i3 = e3.buttonTheme, o2 = e3.position, l2 = "chart" === e3.relativeTo || "spacingBox" === e3.relativeTo ? void 0 : "plotBox", s2 = this.group.getBBox(), r2 = 2 * (i3.padding || 0) + e3.buttonSpacing;
              o2.width = s2.width + r2, o2.height = s2.height + r2;
              let n2 = h(o2);
              t3 && (n2.x += t3), this.options.rtl && (n2.x += o2.width), n2.y = c(n2.y, this.yOffset, 0), this.group.align(n2, true, l2);
            }
          }
          renderButton(t3, e3, i3) {
            let o2 = this, l2 = this.chart, s2 = o2.options, r2 = h(s2.buttonTheme), n2 = l2.renderer.button(o2.getButtonText(t3), e3, i3, function(e4) {
              let i4;
              let l3 = s2.events && s2.events.click;
              l3 && (i4 = l3.call(o2, e4, t3)), false !== i4 && (s2.showFullPath ? e4.newLevel = t3.level : e4.newLevel = o2.level - 1, d(o2, "up", e4));
            }, r2).addClass("highcharts-breadcrumbs-button").add(o2.group);
            return l2.styledMode || n2.attr(s2.style), n2;
          }
          renderSeparator(t3, e3) {
            let i3 = this.chart, o2 = this.options.separator, l2 = i3.renderer.label(o2.text, t3, e3, void 0, void 0, void 0, false).addClass("highcharts-breadcrumbs-separator").add(this.group);
            return i3.styledMode || l2.css(o2.style), l2;
          }
          update(t3) {
            h(true, this.options, t3), this.destroy(), this.isDirty = true;
          }
          updateSingleButton() {
            let t3 = this.chart, e3 = this.list[this.level - 1];
            t3.drillUpButton && t3.drillUpButton.attr({ text: this.getButtonText(e3) });
          }
          destroy() {
            this.destroySingleButton(), this.destroyListElements(true), this.group && this.group.destroy(), this.group = void 0;
          }
          destroyListElements(t3) {
            let e3 = this.elementList;
            u(e3, (i3, o2) => {
              (t3 || !e3[o2].updated) && ((i3 = e3[o2]).button && i3.button.destroy(), i3.separator && i3.separator.destroy(), delete i3.button, delete i3.separator, delete e3[o2]);
            }), t3 && (this.elementList = {});
          }
          destroySingleButton() {
            this.chart.drillUpButton && (this.chart.drillUpButton.destroy(), this.chart.drillUpButton = void 0);
          }
          resetElementListState() {
            u(this.elementList, (t3) => {
              t3.updated = false;
            });
          }
          updateListElements() {
            let t3 = this.elementList, e3 = this.options.buttonSpacing, i3 = this.list, o2 = this.options.rtl, l2 = o2 ? -1 : 1, s2 = function(t4, e4) {
              return l2 * t4.getBBox().width + l2 * e4;
            }, r2 = function(t4, e4, i4) {
              t4.translate(e4 - t4.getBBox().width, i4);
            }, n2 = this.group ? s2(this.group, e3) : e3, a2, d2;
            for (let p2 = 0, h2 = i3.length; p2 < h2; ++p2) {
              let u2, c2;
              let m2 = p2 === h2 - 1;
              t3[(d2 = i3[p2]).level] ? (u2 = (a2 = t3[d2.level]).button, a2.separator || m2 ? a2.separator && m2 && (a2.separator.destroy(), delete a2.separator) : (n2 += l2 * e3, a2.separator = this.renderSeparator(n2, e3), o2 && r2(a2.separator, n2, e3), n2 += s2(a2.separator, e3)), t3[d2.level].updated = true) : (u2 = this.renderButton(d2, n2, e3), o2 && r2(u2, n2, e3), n2 += s2(u2, e3), m2 || (c2 = this.renderSeparator(n2, e3), o2 && r2(c2, n2, e3), n2 += s2(c2, e3)), t3[d2.level] = { button: u2, separator: c2, updated: true }), u2 && u2.setState(m2 ? 2 : 0);
            }
          }
        }
        return y.defaultOptions = t2.options, y;
      }), i(e, "Extensions/Drilldown/DrilldownDefaults.js", [], function() {
        return { activeAxisLabelStyle: { cursor: "pointer", color: "#0022ff", fontWeight: "bold", textDecoration: "underline" }, activeDataLabelStyle: { cursor: "pointer", color: "#0022ff", fontWeight: "bold", textDecoration: "underline" }, animation: { duration: 500 }, drillUpButton: { position: { align: "right", x: -10, y: 10 } }, mapZooming: true };
      }), i(e, "Extensions/Drilldown/DrilldownSeries.js", [e["Core/Animation/AnimationUtilities.js"], e["Core/Utilities.js"]], function(t2, e2) {
        let { animObject: i2 } = t2, { addEvent: o, extend: l, fireEvent: s, merge: r, pick: n, syncTimeout: a } = e2;
        function d(t3, e3, i3, o2) {
          t3[i3 ? "addClass" : "removeClass"]("highcharts-drilldown-point"), o2 || t3.css({ cursor: e3 });
        }
        function p(t3) {
          let e3 = this, o2 = e3.chart, s2 = o2.drilldownLevels, r2 = i2((o2.options.drilldown || {}).animation), a2 = this.xAxis, d2 = o2.styledMode;
          if (!t3) {
            let t4;
            (s2 || []).forEach((i3) => {
              e3.options._ddSeriesId === i3.lowerSeriesOptions._ddSeriesId && (t4 = i3.shapeArgs, !d2 && t4 && (t4.fill = i3.color));
            }), t4.x += n(a2.oldPos, a2.pos) - a2.pos, e3.points.forEach((i3) => {
              let o3 = i3.shapeArgs;
              d2 || (o3.fill = i3.color), i3.graphic && i3.graphic.attr(t4).animate(l(i3.shapeArgs, { fill: i3.color || e3.color }), r2);
            }), o2.drilldown && o2.drilldown.fadeInGroup(this.dataLabelsGroup), delete this.animate;
          }
        }
        function h(t3) {
          let e3 = this, o2 = i2((e3.chart.options.drilldown || {}).animation);
          (e3.trackerGroups || []).forEach((t4) => {
            e3[t4] && e3[t4].on("mouseover");
          });
          let l2 = e3.group, s2 = l2 !== e3.chart.columnGroup;
          s2 && delete e3.group, this.points.forEach((i3) => {
            let n2 = i3.graphic, a2 = t3.shapeArgs;
            if (n2 && a2) {
              let d2 = () => {
                n2.destroy(), l2 && s2 && (l2 = l2.destroy());
              };
              delete i3.graphic, e3.chart.styledMode || (a2.fill = t3.color), o2.duration ? n2.animate(a2, r(o2, { complete: d2 })) : (n2.attr(a2), d2());
            }
          });
        }
        function u(t3) {
          let e3 = this, i3 = e3.drilldownLevel;
          t3 || (e3.points.forEach((t4) => {
            let e4 = t4.dataLabel;
            t4.graphic && t4.graphic.hide(), e4 && (e4.hidden = "hidden" === e4.attr("visibility"), e4.hidden || (e4.hide(), e4.connector?.hide()));
          }), a(() => {
            if (e3.points) {
              let t4 = [];
              e3.data.forEach((e4) => {
                t4.push(e4);
              }), e3.nodes && (t4 = t4.concat(e3.nodes)), t4.forEach((t5, e4) => {
                let o2 = e4 === (i3 && i3.pointIndex) ? "show" : "fadeIn", l2 = t5.dataLabel;
                t5.graphic && t5.visible && t5.graphic[o2]("show" === o2 || void 0), l2 && !l2.hidden && (l2.fadeIn(), l2.connector?.fadeIn());
              });
            }
          }, Math.max(e3.chart.options.drilldown.animation.duration - 50, 0)), delete this.animate);
        }
        function c(t3) {
          let e3 = this, i3 = e3.chart, o2 = e3.group;
          i3 && o2 && e3.options && i3.options.drilldown && i3.options.drilldown.animation && (t3 && i3.mapView ? (o2.attr({ opacity: 0.01 }), i3.mapView.allowTransformAnimation = false, e3.options.inactiveOtherPoints = true, e3.options.enableMouseTracking = false) : (o2.animate({ opacity: 1 }, i3.options.drilldown.animation, () => {
            e3.options && (e3.options.inactiveOtherPoints = false, e3.options.enableMouseTracking = n(e3.userOptions && e3.userOptions.enableMouseTracking, true), e3.isDirty = true, i3.redraw());
          }), i3.drilldown && i3.drilldown.fadeInGroup(this.dataLabelsGroup)));
        }
        function m() {
          let t3 = this.chart;
          t3 && t3.mapView && (t3.mapView.allowTransformAnimation = false), this.options && (this.options.inactiveOtherPoints = true);
        }
        function w(t3) {
          let e3 = this.chart, i3 = this.group;
          e3 && i3 && (t3 ? (i3.attr({ opacity: 0.01 }), this.options && (this.options.inactiveOtherPoints = true)) : (i3.animate({ opacity: 1 }, (e3.options.drilldown || {}).animation), e3.drilldown && e3.drilldown.fadeInGroup(this.dataLabelsGroup)));
        }
        function f() {
          return this.drilldown && !this.unbindDrilldownClick && (this.unbindDrilldownClick = o(this, "click", b)), this;
        }
        function g() {
          let t3 = this.series, e3 = t3.chart.styledMode;
          this.drilldown && t3.halo && "hover" === this.state ? d(t3.halo, "pointer", true, e3) : t3.halo && d(t3.halo, "auto", false, e3);
        }
        function b(t3) {
          let e3 = this.series;
          e3.xAxis && false === (e3.chart.options.drilldown || {}).allowPointDrilldown ? e3.xAxis.drilldownCategory(this.x, t3) : this.runDrilldown(void 0, void 0, t3);
        }
        function v(t3) {
          let e3 = t3.options || {};
          e3.drilldown && !this.unbindDrilldownClick ? this.unbindDrilldownClick = o(this, "click", b) : !e3.drilldown && void 0 !== e3.drilldown && this.unbindDrilldownClick && (this.unbindDrilldownClick = this.unbindDrilldownClick());
        }
        function y() {
          let t3 = this.chart, e3 = t3.options.drilldown.activeDataLabelStyle, i3 = t3.renderer, o2 = t3.styledMode;
          for (let t4 of this.points) {
            let l2 = t4.options.dataLabels, s2 = n(t4.dlOptions, l2 && l2.style, {});
            t4.drilldown && t4.dataLabel && ("contrast" !== e3.color || o2 || (s2.color = i3.getContrast(t4.color || this.color)), l2 && l2.color && (s2.color = l2.color), t4.dataLabel.addClass("highcharts-drilldown-data-label"), o2 || t4.dataLabel.css(e3).css(s2));
          }
        }
        function D() {
          let t3 = this.chart.styledMode;
          for (let e3 of this.points)
            e3.drilldown && e3.graphic && d(e3.graphic, "pointer", true, t3);
        }
        function x(t3) {
          let e3 = this.chart, i3 = this.points, o2 = e3.drilldownLevels[e3.drilldownLevels.length - 1], l2 = e3.options.drilldown.animation;
          if (this.is("item") && (l2.duration = 0), this.center) {
            let s2 = o2.shapeArgs, n2 = s2.start, a2 = (s2.end - n2) / this.points.length, d2 = e3.styledMode;
            if (!t3) {
              let t4, p2;
              for (let e4 = 0, h2 = i3.length; e4 < h2; ++e4)
                t4 = (p2 = i3[e4]).shapeArgs, d2 || (s2.fill = o2.color, t4.fill = p2.color), p2.graphic && p2.graphic.attr(r(s2, { start: n2 + e4 * a2, end: n2 + (e4 + 1) * a2 }))[l2 ? "animate" : "attr"](t4, l2);
              e3.drilldown && e3.drilldown.fadeInGroup(this.dataLabelsGroup), delete this.animate;
            }
          }
        }
        function S() {
          this.runDrilldown();
        }
        function B(t3, e3, i3) {
          let o2 = this.series, l2 = o2.chart, r2 = l2.options.drilldown || {}, n2 = (r2.series || []).length, a2;
          for (l2.ddDupes || (l2.ddDupes = []), l2.colorCounter = l2.symbolCounter = 0; n2-- && !a2; )
            r2.series && r2.series[n2].id === this.drilldown && this.drilldown && -1 === l2.ddDupes.indexOf(this.drilldown) && (a2 = r2.series[n2], l2.ddDupes.push(this.drilldown));
          s(l2, "drilldown", { point: this, seriesOptions: a2, category: e3, originalEvent: i3, points: void 0 !== e3 && o2.xAxis.getDDPoints(e3).slice(0) }, (e4) => {
            let i4 = e4.point.series && e4.point.series.chart, o3 = e4.seriesOptions;
            i4 && o3 && (t3 ? i4.addSingleSeriesAsDrilldown(e4.point, o3) : i4.addSeriesAsDrilldown(e4.point, o3));
          });
        }
        return { compose: function(t3, e3) {
          let i3 = t3.prototype.pointClass, l2 = i3.prototype;
          if (!l2.doDrilldown) {
            let { column: s2, map: r2, pie: n2 } = e3;
            if (o(i3, "afterInit", f), o(i3, "afterSetState", g), o(i3, "update", v), l2.doDrilldown = S, l2.runDrilldown = B, o(t3, "afterDrawDataLabels", y), o(t3, "afterDrawTracker", D), s2) {
              let t4 = s2.prototype;
              t4.animateDrilldown = p, t4.animateDrillupFrom = h, t4.animateDrillupTo = u;
            }
            if (r2) {
              let t4 = r2.prototype;
              t4.animateDrilldown = c, t4.animateDrillupFrom = m, t4.animateDrillupTo = w;
            }
            if (n2) {
              let t4 = n2.prototype;
              t4.animateDrilldown = x, t4.animateDrillupFrom = h, t4.animateDrillupTo = u;
            }
          }
        } };
      }), i(e, "Extensions/Drilldown/Drilldown.js", [e["Core/Animation/AnimationUtilities.js"], e["Extensions/Breadcrumbs/Breadcrumbs.js"], e["Core/Color/Color.js"], e["Core/Globals.js"], e["Extensions/Drilldown/DrilldownDefaults.js"], e["Extensions/Drilldown/DrilldownSeries.js"], e["Core/Utilities.js"]], function(t2, e2, i2, o, l, s, r) {
        var n;
        let { animObject: a } = t2, { noop: d } = o, { addEvent: p, defined: h, diffObjects: u, extend: c, fireEvent: m, merge: w, objectEach: f, pick: g, removeEvent: b, syncTimeout: v } = r, y = 1;
        function D(t3, e3) {
          this.getDDPoints(t3).forEach(function(i3) {
            i3 && i3.series && i3.series.visible && i3.runDrilldown && i3.runDrilldown(true, t3, e3);
          }), this.chart.applyDrilldown();
        }
        function x(t3) {
          return this.ddPoints && this.ddPoints[t3] || [];
        }
        function S(t3) {
          let e3 = [], i3 = t3.drilldownLevels;
          return i3 && i3.length && (e3[0] || e3.push({ level: 0, levelOptions: i3[0].seriesOptions }), i3.forEach(function(t4) {
            let i4 = e3[e3.length - 1];
            t4.levelNumber + 1 > i4.level && e3.push({ level: t4.levelNumber + 1, levelOptions: w({ name: t4.lowerSeries.name }, t4.pointOptions) });
          })), e3;
        }
        class B {
          constructor(t3) {
            this.chart = t3;
          }
          addSeriesAsDrilldown(t3, e3) {
            let i3 = this.chart || this;
            if (m(this, "addSeriesAsDrilldown", { seriesOptions: e3 }), i3.mapView) {
              if (t3.series.isDrilling = true, i3.series.forEach((t4) => {
                t4.options.inactiveOtherPoints = true, t4.dataLabelsGroup?.destroy(), delete t4.dataLabelsGroup;
              }), i3.options.drilldown && !i3.mapView.projection.hasGeoProjection && l && !h(u(i3.options.drilldown, l).mapZooming) && (i3.options.drilldown.mapZooming = false), i3.options.drilldown && i3.options.drilldown.animation && i3.options.drilldown.mapZooming) {
                i3.mapView.allowTransformAnimation = true;
                let o2 = a(i3.options.drilldown.animation);
                if ("boolean" != typeof o2) {
                  let l2 = o2.complete, s2 = function(o3) {
                    o3 && o3.applyDrilldown && i3.mapView && (i3.addSingleSeriesAsDrilldown(t3, e3), i3.applyDrilldown(), i3.mapView.allowTransformAnimation = false);
                  };
                  o2.complete = function() {
                    l2 && l2.apply(this, arguments), s2.apply(this, arguments);
                  };
                }
                t3.zoomTo(o2);
              } else
                i3.addSingleSeriesAsDrilldown(t3, e3), i3.applyDrilldown();
            } else
              i3.addSingleSeriesAsDrilldown(t3, e3), i3.applyDrilldown();
          }
          addSingleSeriesAsDrilldown(t3, e3) {
            let o2 = this.chart || this, l2 = t3.series, s2 = l2.xAxis, r2 = l2.yAxis, n2 = o2.styledMode ? { colorIndex: g(t3.colorIndex, l2.colorIndex) } : { color: t3.color || l2.color }, a2 = l2.options._levelNumber || 0, p2 = l2.points.indexOf(t3);
            o2.drilldownLevels || (o2.drilldownLevels = []), e3 = c(c({ _ddSeriesId: y++ }, n2), e3);
            let h2 = [], u2 = [], m2;
            (m2 = o2.drilldownLevels[o2.drilldownLevels.length - 1]) && m2.levelNumber !== a2 && (m2 = void 0), l2.chart.series.forEach((t4) => {
              t4.xAxis === s2 && (t4.options._ddSeriesId = t4.options._ddSeriesId || y++, t4.options.colorIndex = t4.colorIndex, t4.options._levelNumber = t4.options._levelNumber || a2, m2 ? (h2 = m2.levelSeries, u2 = m2.levelSeriesOptions) : (h2.push(t4), t4.purgedOptions = w({ _ddSeriesId: t4.options._ddSeriesId, _levelNumber: t4.options._levelNumber, selected: t4.options.selected }, t4.userOptions), u2.push(t4.purgedOptions)));
            });
            let f2 = c({ levelNumber: a2, seriesOptions: l2.options, seriesPurgedOptions: l2.purgedOptions, levelSeriesOptions: u2, levelSeries: h2, shapeArgs: t3.shapeArgs, bBox: t3.graphic ? t3.graphic.getBBox() : {}, color: t3.isNull ? i2.parse(n2.color).setOpacity(0).get() : n2.color, lowerSeriesOptions: e3, pointOptions: l2.options.data[p2], pointIndex: p2, oldExtremes: { xMin: s2 && s2.userMin, xMax: s2 && s2.userMax, yMin: r2 && r2.userMin, yMax: r2 && r2.userMax }, resetZoomButton: m2 && m2.levelNumber === a2 ? void 0 : o2.resetZoomButton }, n2);
            o2.drilldownLevels.push(f2), s2 && s2.names && (s2.names.length = 0);
            let b2 = f2.lowerSeries = o2.addSeries(e3, false);
            b2.options._levelNumber = a2 + 1, s2 && (s2.oldPos = s2.pos, s2.userMin = s2.userMax = null, r2.userMin = r2.userMax = null), b2.isDrilling = true, l2.type === b2.type && (b2.animate = b2.animateDrilldown || d, b2.options.animation = true);
          }
          applyDrilldown() {
            let t3;
            let e3 = this.chart || this, i3 = e3.drilldownLevels;
            i3 && i3.length > 0 && (t3 = i3[i3.length - 1].levelNumber, e3.hasCartesianSeries = i3.some((t4) => t4.lowerSeries.isCartesian), (e3.drilldownLevels || []).forEach((i4) => {
              e3.mapView && e3.options.drilldown && e3.options.drilldown.mapZooming && (e3.redraw(), i4.lowerSeries.isDrilling = false, e3.mapView.fitToBounds(i4.lowerSeries.bounds), i4.lowerSeries.isDrilling = true), i4.levelNumber === t3 && i4.levelSeries.forEach((o2) => {
                if (e3.mapView) {
                  if (o2.options && o2.options._levelNumber === t3 && o2.group) {
                    let t4 = {};
                    e3.options.drilldown && (t4 = e3.options.drilldown.animation), o2.group.animate({ opacity: 0 }, t4, () => {
                      o2.remove(false), i4.levelSeries.filter((t5) => Object.keys(t5).length).length || (e3.resetZoomButton && (e3.resetZoomButton.hide(), delete e3.resetZoomButton), e3.pointer?.reset(), m(e3, "afterDrilldown"), e3.mapView && (e3.series.forEach((t5) => {
                        t5.isDirtyData = true, t5.isDrilling = false;
                      }), e3.mapView.fitToBounds(void 0, void 0)), m(e3, "afterApplyDrilldown"));
                    });
                  }
                } else
                  o2.options && o2.options._levelNumber === t3 && o2.remove(false);
              });
            })), e3.mapView || (e3.resetZoomButton && (e3.resetZoomButton.hide(), delete e3.resetZoomButton), e3.pointer?.reset(), m(e3, "afterDrilldown"), e3.hasCartesianSeries || e3.axes.forEach((t4) => {
              t4.destroy(true), t4.init(e3, w(t4.userOptions, t4.options));
            }), e3.redraw(), m(e3, "afterApplyDrilldown"));
          }
          drillUp(t3) {
            let e3 = this.chart || this;
            if (!e3.drilldownLevels || 0 === e3.drilldownLevels.length)
              return;
            m(e3, "beforeDrillUp");
            let i3 = e3.drilldownLevels, o2 = i3[i3.length - 1].levelNumber, l2 = e3.series, s2 = e3.drilldownLevels.length, r2 = (t4, i4) => {
              let o3;
              if (l2.forEach((e4) => {
                e4.options._ddSeriesId === t4._ddSeriesId && (o3 = e4);
              }), (o3 = o3 || e3.addSeries(t4, false)).type === i4.type && o3.animateDrillupTo && (o3.animate = o3.animateDrillupTo), t4 === p2.seriesPurgedOptions)
                return o3;
            }, n2 = (t4) => {
              t4.remove(false), e3.series.forEach((t5) => {
                t5.colorAxis && (t5.isDirtyData = true), t5.options.inactiveOtherPoints = false;
              }), e3.redraw();
            }, a2 = i3.length, d2, p2, h2;
            for (e3.symbolCounter = e3.colorCounter = 0; a2--; ) {
              let u2, c2;
              if ((p2 = i3[a2]).levelNumber === o2) {
                if (i3.pop(), !(u2 = p2.lowerSeries).chart) {
                  for (d2 = l2.length; d2--; )
                    if (l2[d2].options.id === p2.lowerSeriesOptions.id && l2[d2].options._levelNumber === o2 + 1) {
                      u2 = l2[d2];
                      break;
                    }
                }
                u2.xData = [], u2.xAxis && u2.xAxis.names && (0 === s2 || a2 === s2) && (u2.xAxis.names.length = 0), p2.levelSeriesOptions.forEach((t4) => {
                  let e4 = r2(t4, u2);
                  e4 && (c2 = e4);
                }), m(e3, "drillup", { seriesOptions: p2.seriesPurgedOptions || p2.seriesOptions }), c2 && (c2.type === u2.type && (c2.drilldownLevel = p2, c2.options.animation = e3.options.drilldown.animation, u2.animateDrillupFrom && u2.chart && u2.animateDrillupFrom(p2)), c2.options._levelNumber = o2);
                let w2 = u2;
                if (e3.mapView || w2.remove(false), c2 && c2.xAxis && (h2 = p2.oldExtremes, c2.xAxis.setExtremes(h2.xMin, h2.xMax, false), c2.yAxis.setExtremes(h2.yMin, h2.yMax, false)), p2.resetZoomButton && (e3.resetZoomButton = p2.resetZoomButton), e3.mapView) {
                  let i4 = p2.levelNumber === o2 && t3, l3 = e3.options.drilldown && e3.options.drilldown.animation && e3.options.drilldown.mapZooming;
                  i4 ? u2.remove(false) : (u2.dataLabelsGroup && (u2.dataLabelsGroup.destroy(), delete u2.dataLabelsGroup), e3.mapView && c2 && (l3 && (u2.isDrilling = true, c2.isDrilling = true, e3.redraw(false), e3.mapView.fitToBounds(u2.bounds, void 0, true, false)), e3.mapView.allowTransformAnimation = true, m(e3, "afterDrillUp", { seriesOptions: c2 ? c2.userOptions : void 0 }), l3 ? e3.mapView.setView(void 0, g(e3.mapView.minZoom, 1), true, { complete: function() {
                    Object.prototype.hasOwnProperty.call(this, "complete") && n2(u2);
                  } }) : (e3.mapView.allowTransformAnimation = false, u2.group ? u2.group.animate({ opacity: 0 }, e3.options.drilldown.animation, () => {
                    n2(u2), e3.mapView && (e3.mapView.allowTransformAnimation = true);
                  }) : (n2(u2), e3.mapView.allowTransformAnimation = true)), c2.isDrilling = false, e3.ddDupes && (e3.ddDupes.length = 0), m(e3, "drillupall")));
                } else
                  m(e3, "afterDrillUp"), e3.redraw(), e3.ddDupes && (e3.ddDupes.length = 0), m(e3, "drillupall");
              }
            }
          }
          fadeInGroup(t3) {
            let e3 = a(this.chart.options.drilldown.animation);
            t3 && (t3.hide(), v(() => {
              t3 && t3.added && t3.fadeIn();
            }, Math.max(e3.duration - 50, 0)));
          }
          update(t3, e3) {
            let i3 = this.chart;
            w(true, i3.options.drilldown, t3), g(e3, true) && i3.redraw();
          }
        }
        return function(t3) {
          function i3(t4) {
            let e3 = this.chart, i4 = this.getLevel() - t4.newLevel, o3 = i4 > 1;
            for (let t5 = 0; t5 < i4; t5++)
              t5 === i4 - 1 && (o3 = false), e3.drillUp(o3);
          }
          function o2() {
            let t4 = this.options.drilldown, i4 = t4 && t4.breadcrumbs;
            this.breadcrumbs || (this.breadcrumbs = new e2(this, i4)), this.breadcrumbs.updateProperties(S(this));
          }
          function r2() {
            this.breadcrumbs && this.breadcrumbs.updateProperties(S(this));
          }
          function n2() {
            this.drilldown = new B(this);
          }
          function a2() {
            this.resetZoomButton && (this.resetZoomButton = this.resetZoomButton.destroy());
          }
          function d2() {
            this.resetZoomButton && this.showResetZoom();
          }
          function h2() {
            (this.xAxis || []).forEach((t4) => {
              t4.ddPoints = {}, t4.series.forEach((e3) => {
                let i4 = e3.xData || [], o3 = e3.points;
                for (let l2 = 0, s2 = i4.length, r3; l2 < s2; l2++)
                  if ("number" != typeof (r3 = e3.options.data[l2]) && (r3 = e3.pointClass.prototype.optionsToObject.call({ series: e3 }, r3)).drilldown) {
                    t4.ddPoints[i4[l2]] || (t4.ddPoints[i4[l2]] = []);
                    let s3 = l2 - (e3.cropStart || 0);
                    t4.ddPoints[i4[l2]].push(!o3 || !(s3 >= 0) || !(s3 < o3.length) || o3[s3]);
                  }
              }), f(t4.ticks, (t5) => t5.drillable());
            });
          }
          function u2(t4) {
            let e3 = this.breadcrumbs, i4 = t4.options.drilldown && t4.options.drilldown.breadcrumbs;
            e3 && i4 && e3.update(i4);
          }
          function c2(t4) {
            this.attr({ opacity: 0.1, visibility: "inherit" }).animate({ opacity: g(this.newOpacity, 1) }, t4 || { duration: 250 });
          }
          function m2() {
            let t4 = this.pos, e3 = this.label, i4 = this.axis, o3 = "xAxis" === i4.coll && i4.getDDPoints, l2 = o3 && i4.getDDPoints(t4), s2 = i4.chart.styledMode;
            o3 && (e3 && l2 && l2.length ? (e3.drillable = true, e3.basicStyles || s2 || (e3.basicStyles = w(e3.styles)), e3.addClass("highcharts-drilldown-axis-label"), e3.removeOnDrillableClick && b(e3.element, "click"), e3.removeOnDrillableClick = p(e3.element, "click", function(e4) {
              e4.preventDefault(), i4.drilldownCategory(t4, e4);
            }), !s2 && i4.chart.options.drilldown && e3.css(i4.chart.options.drilldown.activeAxisLabelStyle || {})) : e3 && e3.drillable && e3.removeOnDrillableClick && (s2 || (e3.styles = {}, e3.element.removeAttribute("style"), e3.css(e3.basicStyles)), e3.removeOnDrillableClick(), e3.removeClass("highcharts-drilldown-axis-label")));
          }
          t3.compose = function(t4, w2, f2, g2, b2, v2, y2) {
            s.compose(g2, b2);
            let S2 = w2.prototype;
            if (!S2.drillUp) {
              let s2 = v2.prototype.Element, g3 = B.prototype, b3 = t4.prototype, L = s2.prototype, O = y2.prototype;
              b3.drilldownCategory = D, b3.getDDPoints = x, e2.compose(w2, f2), p(e2, "up", i3), S2.addSeriesAsDrilldown = g3.addSeriesAsDrilldown, S2.addSingleSeriesAsDrilldown = g3.addSingleSeriesAsDrilldown, S2.applyDrilldown = g3.applyDrilldown, S2.drillUp = g3.drillUp, p(w2, "afterDrilldown", o2), p(w2, "afterDrillUp", r2), p(w2, "afterInit", n2), p(w2, "drillup", a2), p(w2, "drillupall", d2), p(w2, "render", h2), p(w2, "update", u2), f2.drilldown = l, L.fadeIn = c2, O.drillable = m2;
            }
          };
        }(n || (n = {})), n;
      }), i(e, "masters/modules/drilldown.src.js", [e["Core/Globals.js"], e["Extensions/Drilldown/Drilldown.js"], e["Extensions/Breadcrumbs/Breadcrumbs.js"]], function(t2, e2, i2) {
        return t2.Breadcrumbs = t2.Breadcrumbs || i2, e2.compose(t2.Axis, t2.Chart, t2.defaultOptions, t2.Series, t2.seriesTypes, t2.SVGRenderer, t2.Tick), t2;
      });
    });
  }
});
export default require_drilldown();
//# sourceMappingURL=highcharts_modules_drilldown.js.map
