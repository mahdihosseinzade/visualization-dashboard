import {WeekNameType} from "../../types/week-name-type/week-name-type";

export interface WeekModel {
  name: WeekNameType,
  count: number
}
