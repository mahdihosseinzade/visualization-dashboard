export type WeekNameType = 'Week 1' | 'Week 2' | 'Week 3' | 'Week 4';
